//
//  perfectNumber.swift
//  assignment3
//
//  Created by Nicholas Hudeck on 2/8/16.
//  Copyright © 2016 Nicholas Hudeck. All rights reserved.
//

import Foundation
import UIKit


class PerfectNumber : ViewController{
    
    
    
    
    func checkNumber(start: Int, end: Int) -> Int {
        
        var value : Int = 0
        
        for index in start...end{
            if isPerfectNumber(index){
                value = index
            }
        }
        
        if value == 0 {
            //set UI alert
        }
        else {
            //set UI alert
        }
        
        
        
        
    }
}

    
    
    
    func isPerfectNumber(num: Int) -> Bool{
        var sum = 0
        
        for (var i = 1; i <= num; i++){
            if(num%i == 0){
                sum += i
            }
        }
        
        //print(sum)
        
        if(sum/2 == num){
            return true
        }
        else{
            return false
        }
        
    }
    
    
    
}