//
//  ViewController.swift
//  assignment3
//
//  Created by Nicholas Hudeck on 2/5/16.
//  Copyright © 2016 Nicholas Hudeck. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var startInteger: UITextField!

    @IBOutlet weak var endInteger: UITextField!
    
//    @IBOutlet weak var labelToChange: UILabel!
    
    @IBAction func submitNumbers(sender: AnyObject) {
        let s = Int(startInteger.text!)
        let e = Int(endInteger.text!)
        let title = NSLocalizedString("Perfect Number", comment: "")
        let cancelButtonTitle = NSLocalizedString("OK", comment: "")
        

        func checkNumber() {
            
            var value = 0
            
            for var i = s!; i <= e; ++i{
                if isPerfectNumber(i){
                    value = i
                    break
                }
            }
            
           // labelToChange.text = String(value)
            
            
            
            if value == 0 {
                //set UI alert
                //showSimpleAlert("There is no perfect number between")
                let message = NSLocalizedString("There is no perfect number between given values", comment: "")
                let alertController = UIAlertController(title: title , message: message, preferredStyle: .Alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)

            }
            else {
                //set UI alert
                //showSimpleAlert("The first perfect number is \(value)")
                let message = NSLocalizedString("The first perfect number is \(value)", comment: "")
                let alertController = UIAlertController(title: title , message: message, preferredStyle: .Alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)
            }
            
        }
        
        checkNumber()
        
        
        func isPerfectNumber(num: Int) -> Bool{
            var sum = 0
            
            for (var i = 1; i <= num; i++){
                if(num%i == 0){
                    sum += i
                }
            }
            
            //print(sum)
            
            if(sum/2 == num){
                return true
            }
            else{
                return false
            }
            
        }

        
        
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showSimpleAlert(msg: String) {
        let title = NSLocalizedString("Perfect Number", comment: "")
        let message = NSLocalizedString(msg, comment: "")
        let cancelButtonTitle = NSLocalizedString("OK", comment: "")
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        // Create the action.
        let cancelAction = UIAlertAction(title: cancelButtonTitle, style: .Cancel) { action in
            NSLog("The simple alert's cancel action occured.")
        }
        
        // Add the action.
        alertController.addAction(cancelAction)
        
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    
    


    
   
   

}



/*
class PerfectNumber{
    
    var start: Int
    var end: Int
    var val: Int
    
    
    init(start: Int, end: Int){
        self.start = start
        self.end = end
        val = 0
    }
    
    







}
*/
