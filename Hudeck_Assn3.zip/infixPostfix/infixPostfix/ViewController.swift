//
//  ViewController.swift
//  infixPostfix
//
//  Created by Nicholas Hudeck on 2/8/16.
//  Copyright © 2016 Nicholas Hudeck. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {

    @IBOutlet weak var infixField: UITextField!
    
    @IBOutlet weak var postfixLabel: UILabel!
    
    
    @IBAction func generatePostfix(sender: AnyObject) {
        let eval = infixField.text!
        
        if(Operate.checkEvaluation(eval)){
            postfixLabel.text! = Operate.infixToPostfix(eval)
        }
        else {
            postfixLabel.text! = "Please use a valid infix, such as 5+((1+2)*4)-3"
        }
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}



class Stack<T>{
    private var top: Int
    private var items: [T]
    var size: Int
    
    
    init(size:Int){
        top = -1
        items = [T]()
        self.size = size
    }
    
    func push(item: T) -> Bool {
        if !isFull(){
            items.append(item)
            top++
            return true
        }
        return false
    }
    
    func pop() -> T? {
        if !isEmpty() {
            top--
            return items.removeLast()
        }
        return nil
    }
    
    func peek() -> T? {
        if !isEmpty() {
            return items.last
        }
        return nil
    }
    
    func isEmpty() -> Bool {
        return top ==  -1
    }
    
    func isFull() -> Bool {
        return top == (size-1)
    }
    
    func count() -> Int {
        return (top + 1)
    }
}



class Operate {
    
    init(){}
    
    class func checkEvaluation(equation: String) -> Bool {
        
        //returns the opposing side symbol ( -> ) { -> } [ -> ]
        func getOtherSymbol(unit: Character) -> Character {
            if unit == ")"{
                return "("
            }
            else if unit == "]"{
                return "["
            }
            else {
                return "{"
            }
        }
        
        //initialization of stack to the size of the incoming infix
        let stack: Stack = Stack<Character>(size: equation.characters.count)
        
        var isNumber: Bool = false
        
        for unit in equation.characters {
            
            //switch based on the current character/unit
            switch unit {
            case "{","[","(":
                stack.push(unit)
                isNumber = false
            case "}","]",")":
                if !stack.isEmpty() && (stack.peek()! == getOtherSymbol(unit)) {
                    stack.pop()!
                    isNumber = false
                }
                else {
                    return false
                }
            case "+","-","*","/":
                isNumber = false
                continue
                
            default:
                if isNumber == true{
                    return false
                }
                else {
                    isNumber = true
                }
            }//end switch
            
        }//end for
        
        
        
        return true
    }//end checkEvaluation
    
    
    
    class func infixToPostfix(equation: String) -> String {
        var result: String = ""
        let stack: Stack = Stack<Character>(size: equation.characters.count)
        
        for char in equation.characters {
            switch char {
            case "+", "-", "*", "/":
                if char == "-" || char == "+" {
                    if stack.isEmpty() {
                        stack.push(char)
                    }
                    else {
                        switch stack.peek()! {
                            
                        case "+", "-", "/", "*":
                            while !stack.isEmpty() && (stack.peek()! == "+" || stack.peek()! == "-" || stack.peek()! == "*" || stack.peek()! == "/")  {
                                result.append(stack.pop()!)
                            }
                            stack.push(char)
                            
                        default:
                            stack.push(char)
                        }
                    }
                }
                else {
                    if stack.isEmpty() {
                        stack.push(char)
                    }
                    else {
                        switch stack.peek()! {
                            
                        case "*", "/":
                            while (stack.peek()! == "*" || stack.peek()! == "/") && !stack.isEmpty() {
                                result.append(stack.pop()!)
                            }
                            stack.push(char)
                            
                        default:
                            stack.push(char)
                        }
                    }
                }
                
            case "(", "{", "[":
                stack.push(char)
                
            case ")", "}", "]":
                while stack.peek() != "(" && stack.peek() != "{" && stack.peek() != "[" && !stack.isEmpty() {
                    result.append(stack.pop()!)
                }
                stack.pop()
                
            default:
                // its a number.
                result.append(char)
            }
        }
        
        while !stack.isEmpty() {
            if stack.peek()! == "(" || stack.peek()! == "{" || stack.peek()! == "[" {
                stack.pop()
            }
            else {
                result.append(stack.pop()!)
            }
        }
        
        return result
    }
    
    
}